﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tugas1PCD
{
    public partial class frmLogBrightness : Form
    {
        public frmLogBrightness()
        {
            InitializeComponent();
        }

        private void hscLogBrightness_Scroll(object sender, ScrollEventArgs e)
        {
            tbLogBrightness.Text = hscLogBrightness.Value.ToString();
        }

        private void tbLogBrightness_TextChanged(object sender, EventArgs e)
        {
            if ((tbLogBrightness.Text == "") || (tbLogBrightness.Text == "-"))
            {
                hscLogBrightness.Value = 0;
                tbLogBrightness.Text = "0";
            }
            else if ((Convert.ToInt16(tbLogBrightness.Text) <= 127) && (Convert.ToInt16(tbLogBrightness.Text) >= -127))
            {
                hscLogBrightness.Value = Convert.ToInt16(tbLogBrightness.Text);
            }
            else
            {
                MessageBox.Show("Input nilai Error");
                tbLogBrightness.Text = "0";
            }
        }

        private void frmLogBrightness_Load(object sender, EventArgs e)
        {
            tbLogBrightness.Text = hscLogBrightness.Value.ToString();
        }

        private void tbOK_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
