﻿namespace Tugas1PCD
{
    partial class frmLogContrast
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbLogContrast = new System.Windows.Forms.TextBox();
            this.hscLogContrast = new System.Windows.Forms.HScrollBar();
            this.tbOK = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // tbLogContrast
            // 
            this.tbLogContrast.Location = new System.Drawing.Point(772, 24);
            this.tbLogContrast.Margin = new System.Windows.Forms.Padding(4);
            this.tbLogContrast.Name = "tbLogContrast";
            this.tbLogContrast.Size = new System.Drawing.Size(68, 22);
            this.tbLogContrast.TabIndex = 20;
            this.tbLogContrast.Text = "0";
            this.tbLogContrast.TextChanged += new System.EventHandler(this.tbLogContrast_TextChanged);
            // 
            // hscLogContrast
            // 
            this.hscLogContrast.Location = new System.Drawing.Point(138, 21);
            this.hscLogContrast.Maximum = 127;
            this.hscLogContrast.Name = "hscLogContrast";
            this.hscLogContrast.Size = new System.Drawing.Size(611, 23);
            this.hscLogContrast.TabIndex = 19;
            this.hscLogContrast.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hscLogContrast_Scroll);
            // 
            // tbOK
            // 
            this.tbOK.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOK.Location = new System.Drawing.Point(740, 70);
            this.tbOK.Margin = new System.Windows.Forms.Padding(4);
            this.tbOK.Name = "tbOK";
            this.tbOK.Size = new System.Drawing.Size(100, 32);
            this.tbOK.TabIndex = 18;
            this.tbOK.Text = "OK";
            this.tbOK.UseVisualStyleBackColor = true;
            this.tbOK.Click += new System.EventHandler(this.tbOK_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(13, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 20);
            this.label1.TabIndex = 17;
            this.label1.Text = "Contrast";
            // 
            // frmLogContrast
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(852, 123);
            this.Controls.Add(this.tbLogContrast);
            this.Controls.Add(this.hscLogContrast);
            this.Controls.Add(this.tbOK);
            this.Controls.Add(this.label1);
            this.Name = "frmLogContrast";
            this.Text = "Setting Log Contrast";
            this.Load += new System.EventHandler(this.frmLogContrast_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.TextBox tbLogContrast;
        private System.Windows.Forms.HScrollBar hscLogContrast;
        private System.Windows.Forms.Button tbOK;
        private System.Windows.Forms.Label label1;
    }
}