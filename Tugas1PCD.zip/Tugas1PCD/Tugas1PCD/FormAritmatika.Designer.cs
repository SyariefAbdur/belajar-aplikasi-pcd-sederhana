﻿namespace Tugas1PCD
{
    partial class FormAritmatika
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bukaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.inputAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.inputBToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.simpanSebagaiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.operasiAritmatikaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.penjumlahanToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.penguranganToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.perkalianToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pembagianToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pbInput1 = new System.Windows.Forms.PictureBox();
            this.pbInput2 = new System.Windows.Forms.PictureBox();
            this.pbOutput = new System.Windows.Forms.PictureBox();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.keluarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbInput1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbInput2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbOutput)).BeginInit();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.operasiAritmatikaToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1132, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bukaToolStripMenuItem,
            this.simpanSebagaiToolStripMenuItem,
            this.keluarToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(44, 24);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // bukaToolStripMenuItem
            // 
            this.bukaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.inputAToolStripMenuItem,
            this.inputBToolStripMenuItem});
            this.bukaToolStripMenuItem.Name = "bukaToolStripMenuItem";
            this.bukaToolStripMenuItem.Size = new System.Drawing.Size(216, 26);
            this.bukaToolStripMenuItem.Text = "Buka";
            // 
            // inputAToolStripMenuItem
            // 
            this.inputAToolStripMenuItem.Name = "inputAToolStripMenuItem";
            this.inputAToolStripMenuItem.Size = new System.Drawing.Size(216, 26);
            this.inputAToolStripMenuItem.Text = "Input A";
            this.inputAToolStripMenuItem.Click += new System.EventHandler(this.inputAToolStripMenuItem_Click);
            // 
            // inputBToolStripMenuItem
            // 
            this.inputBToolStripMenuItem.Name = "inputBToolStripMenuItem";
            this.inputBToolStripMenuItem.Size = new System.Drawing.Size(216, 26);
            this.inputBToolStripMenuItem.Text = "Input B";
            this.inputBToolStripMenuItem.Click += new System.EventHandler(this.inputBToolStripMenuItem_Click);
            // 
            // simpanSebagaiToolStripMenuItem
            // 
            this.simpanSebagaiToolStripMenuItem.Name = "simpanSebagaiToolStripMenuItem";
            this.simpanSebagaiToolStripMenuItem.Size = new System.Drawing.Size(216, 26);
            this.simpanSebagaiToolStripMenuItem.Text = "Simpan Sebagai";
            this.simpanSebagaiToolStripMenuItem.Click += new System.EventHandler(this.simpanSebagaiToolStripMenuItem_Click);
            // 
            // operasiAritmatikaToolStripMenuItem
            // 
            this.operasiAritmatikaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.penjumlahanToolStripMenuItem,
            this.penguranganToolStripMenuItem,
            this.perkalianToolStripMenuItem,
            this.pembagianToolStripMenuItem});
            this.operasiAritmatikaToolStripMenuItem.Name = "operasiAritmatikaToolStripMenuItem";
            this.operasiAritmatikaToolStripMenuItem.Size = new System.Drawing.Size(145, 24);
            this.operasiAritmatikaToolStripMenuItem.Text = "Operasi Aritmatika";
            // 
            // penjumlahanToolStripMenuItem
            // 
            this.penjumlahanToolStripMenuItem.Name = "penjumlahanToolStripMenuItem";
            this.penjumlahanToolStripMenuItem.Size = new System.Drawing.Size(216, 26);
            this.penjumlahanToolStripMenuItem.Text = "Penjumlahan";
            this.penjumlahanToolStripMenuItem.Click += new System.EventHandler(this.penjumlahanToolStripMenuItem_Click);
            // 
            // penguranganToolStripMenuItem
            // 
            this.penguranganToolStripMenuItem.Name = "penguranganToolStripMenuItem";
            this.penguranganToolStripMenuItem.Size = new System.Drawing.Size(216, 26);
            this.penguranganToolStripMenuItem.Text = "Pengurangan";
            this.penguranganToolStripMenuItem.Click += new System.EventHandler(this.penguranganToolStripMenuItem_Click);
            // 
            // perkalianToolStripMenuItem
            // 
            this.perkalianToolStripMenuItem.Name = "perkalianToolStripMenuItem";
            this.perkalianToolStripMenuItem.Size = new System.Drawing.Size(216, 26);
            this.perkalianToolStripMenuItem.Text = "Perkalian";
            this.perkalianToolStripMenuItem.Click += new System.EventHandler(this.perkalianToolStripMenuItem_Click);
            // 
            // pembagianToolStripMenuItem
            // 
            this.pembagianToolStripMenuItem.Name = "pembagianToolStripMenuItem";
            this.pembagianToolStripMenuItem.Size = new System.Drawing.Size(216, 26);
            this.pembagianToolStripMenuItem.Text = "Pembagian";
            this.pembagianToolStripMenuItem.Click += new System.EventHandler(this.pembagianToolStripMenuItem_Click);
            // 
            // pbInput1
            // 
            this.pbInput1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbInput1.Location = new System.Drawing.Point(12, 50);
            this.pbInput1.Name = "pbInput1";
            this.pbInput1.Size = new System.Drawing.Size(350, 350);
            this.pbInput1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbInput1.TabIndex = 2;
            this.pbInput1.TabStop = false;
            // 
            // pbInput2
            // 
            this.pbInput2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbInput2.Location = new System.Drawing.Point(392, 50);
            this.pbInput2.Name = "pbInput2";
            this.pbInput2.Size = new System.Drawing.Size(350, 350);
            this.pbInput2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbInput2.TabIndex = 3;
            this.pbInput2.TabStop = false;
            // 
            // pbOutput
            // 
            this.pbOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbOutput.Location = new System.Drawing.Point(770, 50);
            this.pbOutput.Name = "pbOutput";
            this.pbOutput.Size = new System.Drawing.Size(350, 350);
            this.pbOutput.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbOutput.TabIndex = 4;
            this.pbOutput.TabStop = false;
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(0, 420);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(225, 25);
            this.progressBar1.TabIndex = 6;
            this.progressBar1.Visible = false;
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.toolStripStatusLabel2});
            this.statusStrip1.Location = new System.Drawing.Point(0, 448);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1132, 25);
            this.statusStrip1.TabIndex = 5;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(77, 20);
            this.toolStripStatusLabel1.Text = "Lokasi File";
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(98, 20);
            this.toolStripStatusLabel2.Text = "| Resolusi File";
            // 
            // keluarToolStripMenuItem
            // 
            this.keluarToolStripMenuItem.Name = "keluarToolStripMenuItem";
            this.keluarToolStripMenuItem.Size = new System.Drawing.Size(216, 26);
            this.keluarToolStripMenuItem.Text = "Keluar";
            this.keluarToolStripMenuItem.Click += new System.EventHandler(this.keluarToolStripMenuItem_Click);
            // 
            // FormAritmatika
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1132, 473);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.pbOutput);
            this.Controls.Add(this.pbInput2);
            this.Controls.Add(this.pbInput1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "FormAritmatika";
            this.Text = "FormAritmatika";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbInput1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbInput2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbOutput)).EndInit();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem operasiAritmatikaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bukaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem inputAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem inputBToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem simpanSebagaiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem penjumlahanToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem penguranganToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem perkalianToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pembagianToolStripMenuItem;
        private System.Windows.Forms.PictureBox pbInput1;
        private System.Windows.Forms.PictureBox pbInput2;
        private System.Windows.Forms.PictureBox pbOutput;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.ToolStripMenuItem keluarToolStripMenuItem;
    }
}