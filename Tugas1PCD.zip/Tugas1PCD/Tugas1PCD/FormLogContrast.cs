﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tugas1PCD
{
    public partial class frmLogContrast : Form
    {
        public frmLogContrast()
        {
            InitializeComponent();
        }

        private void hscLogContrast_Scroll(object sender, ScrollEventArgs e)
        {
            tbLogContrast.Text = hscLogContrast.Value.ToString();
        }

        private void tbLogContrast_TextChanged(object sender, EventArgs e)
        {
            if ((tbLogContrast.Text == "") || (tbLogContrast.Text == "-"))
            {
                hscLogContrast.Value = 0;
                tbLogContrast.Text = "0";
            }
            else if ((Convert.ToInt16(tbLogContrast.Text) <= 127) && (Convert.ToInt16(tbLogContrast.Text) >= -127))
            {
                hscLogContrast.Value = Convert.ToInt16(tbLogContrast.Text);
            }
            else
            {
                MessageBox.Show("Input nilai Error");
                tbLogContrast.Text = "0";
            }
        }

        private void frmLogContrast_Load(object sender, EventArgs e)
        {
            tbLogContrast.Text = hscLogContrast.Value.ToString();
        }

        private void tbOK_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
