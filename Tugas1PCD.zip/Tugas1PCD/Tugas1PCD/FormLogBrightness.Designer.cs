﻿namespace Tugas1PCD
{
    partial class frmLogBrightness
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbLogBrightness = new System.Windows.Forms.TextBox();
            this.hscLogBrightness = new System.Windows.Forms.HScrollBar();
            this.tbOK = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // tbLogBrightness
            // 
            this.tbLogBrightness.Location = new System.Drawing.Point(772, 32);
            this.tbLogBrightness.Margin = new System.Windows.Forms.Padding(4);
            this.tbLogBrightness.Name = "tbLogBrightness";
            this.tbLogBrightness.Size = new System.Drawing.Size(68, 22);
            this.tbLogBrightness.TabIndex = 16;
            this.tbLogBrightness.Text = "0";
            this.tbLogBrightness.TextChanged += new System.EventHandler(this.tbLogBrightness_TextChanged);
            // 
            // hscLogBrightness
            // 
            this.hscLogBrightness.Location = new System.Drawing.Point(138, 29);
            this.hscLogBrightness.Maximum = 127;
            this.hscLogBrightness.Name = "hscLogBrightness";
            this.hscLogBrightness.Size = new System.Drawing.Size(611, 23);
            this.hscLogBrightness.TabIndex = 14;
            this.hscLogBrightness.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hscLogBrightness_Scroll);
            // 
            // tbOK
            // 
            this.tbOK.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOK.Location = new System.Drawing.Point(740, 78);
            this.tbOK.Margin = new System.Windows.Forms.Padding(4);
            this.tbOK.Name = "tbOK";
            this.tbOK.Size = new System.Drawing.Size(100, 32);
            this.tbOK.TabIndex = 13;
            this.tbOK.Text = "OK";
            this.tbOK.UseVisualStyleBackColor = true;
            this.tbOK.Click += new System.EventHandler(this.tbOK_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(13, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(90, 20);
            this.label1.TabIndex = 11;
            this.label1.Text = "Brightness";
            // 
            // frmLogBrightness
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(852, 123);
            this.Controls.Add(this.tbLogBrightness);
            this.Controls.Add(this.hscLogBrightness);
            this.Controls.Add(this.tbOK);
            this.Controls.Add(this.label1);
            this.Name = "frmLogBrightness";
            this.Text = "Setting Log Brightness";
            this.Load += new System.EventHandler(this.frmLogBrightness_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        public System.Windows.Forms.TextBox tbLogBrightness;
        private System.Windows.Forms.HScrollBar hscLogBrightness;
        private System.Windows.Forms.Button tbOK;
        private System.Windows.Forms.Label label1;
    }
}