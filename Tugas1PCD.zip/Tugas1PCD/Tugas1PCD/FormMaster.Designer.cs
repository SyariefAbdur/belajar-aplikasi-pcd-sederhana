﻿namespace Tugas1PCD
{
    partial class FormMaster
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMaster));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bukaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.simpanSebagaiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.keluarAplikasiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.colorsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.grayscaleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.averageToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lightnessToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.luminanceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.brightnessContrastToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.inverseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logBrightnessToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logContrastToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gammaTransformToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bitDepthToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.satubitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.duabitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tigabitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.empatbitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.limabitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.enambitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tujuhbitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.imageProcessingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.histogramEqualizationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fuzzyHERGBToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fuzzyHEGrayscaleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rGBHistogramToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.inputToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.outputToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.inputOutputToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.grayscaleHistogramToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.inputToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.outputToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.inputOutputToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.operasiAritmatikaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.filterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hPFToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lowPassFilterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.highPassFilterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tentangToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pbInput = new System.Windows.Forms.PictureBox();
            this.pbOutput = new System.Windows.Forms.PictureBox();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.bandPassFIlterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.prowitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sobelToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lineDetectionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.horizontalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.verticalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.pointDetectionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbInput)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbOutput)).BeginInit();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.colorsToolStripMenuItem,
            this.imageProcessingToolStripMenuItem,
            this.viewToolStripMenuItem,
            this.operasiAritmatikaToolStripMenuItem,
            this.filterToolStripMenuItem,
            this.tentangToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(4, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(782, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bukaToolStripMenuItem,
            this.simpanSebagaiToolStripMenuItem,
            this.keluarAplikasiToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // bukaToolStripMenuItem
            // 
            this.bukaToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("bukaToolStripMenuItem.Image")));
            this.bukaToolStripMenuItem.Name = "bukaToolStripMenuItem";
            this.bukaToolStripMenuItem.Size = new System.Drawing.Size(184, 26);
            this.bukaToolStripMenuItem.Text = "Buka";
            this.bukaToolStripMenuItem.Click += new System.EventHandler(this.bukaToolStripMenuItem_Click);
            // 
            // simpanSebagaiToolStripMenuItem
            // 
            this.simpanSebagaiToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("simpanSebagaiToolStripMenuItem.Image")));
            this.simpanSebagaiToolStripMenuItem.Name = "simpanSebagaiToolStripMenuItem";
            this.simpanSebagaiToolStripMenuItem.Size = new System.Drawing.Size(184, 26);
            this.simpanSebagaiToolStripMenuItem.Text = "Simpan Sebagai";
            this.simpanSebagaiToolStripMenuItem.Click += new System.EventHandler(this.simpanSebagaiToolStripMenuItem_Click);
            // 
            // keluarAplikasiToolStripMenuItem
            // 
            this.keluarAplikasiToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("keluarAplikasiToolStripMenuItem.Image")));
            this.keluarAplikasiToolStripMenuItem.Name = "keluarAplikasiToolStripMenuItem";
            this.keluarAplikasiToolStripMenuItem.Size = new System.Drawing.Size(184, 26);
            this.keluarAplikasiToolStripMenuItem.Text = "Keluar Aplikasi";
            this.keluarAplikasiToolStripMenuItem.Click += new System.EventHandler(this.keluarAplikasiToolStripMenuItem_Click);
            // 
            // colorsToolStripMenuItem
            // 
            this.colorsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.grayscaleToolStripMenuItem,
            this.brightnessContrastToolStripMenuItem,
            this.inverseToolStripMenuItem,
            this.logBrightnessToolStripMenuItem,
            this.logContrastToolStripMenuItem,
            this.gammaTransformToolStripMenuItem,
            this.bitDepthToolStripMenuItem});
            this.colorsToolStripMenuItem.Name = "colorsToolStripMenuItem";
            this.colorsToolStripMenuItem.Size = new System.Drawing.Size(53, 20);
            this.colorsToolStripMenuItem.Text = "Colors";
            // 
            // grayscaleToolStripMenuItem
            // 
            this.grayscaleToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.averageToolStripMenuItem,
            this.lightnessToolStripMenuItem,
            this.luminanceToolStripMenuItem});
            this.grayscaleToolStripMenuItem.Name = "grayscaleToolStripMenuItem";
            this.grayscaleToolStripMenuItem.Size = new System.Drawing.Size(185, 22);
            this.grayscaleToolStripMenuItem.Text = "Grayscale";
            // 
            // averageToolStripMenuItem
            // 
            this.averageToolStripMenuItem.Name = "averageToolStripMenuItem";
            this.averageToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.averageToolStripMenuItem.Text = "Average";
            this.averageToolStripMenuItem.Click += new System.EventHandler(this.averageToolStripMenuItem_Click);
            // 
            // lightnessToolStripMenuItem
            // 
            this.lightnessToolStripMenuItem.Name = "lightnessToolStripMenuItem";
            this.lightnessToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.lightnessToolStripMenuItem.Text = "Lightness";
            this.lightnessToolStripMenuItem.Click += new System.EventHandler(this.lightnessToolStripMenuItem_Click);
            // 
            // luminanceToolStripMenuItem
            // 
            this.luminanceToolStripMenuItem.Name = "luminanceToolStripMenuItem";
            this.luminanceToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.luminanceToolStripMenuItem.Text = "Luminance";
            this.luminanceToolStripMenuItem.Click += new System.EventHandler(this.luminanceToolStripMenuItem_Click);
            // 
            // brightnessContrastToolStripMenuItem
            // 
            this.brightnessContrastToolStripMenuItem.Name = "brightnessContrastToolStripMenuItem";
            this.brightnessContrastToolStripMenuItem.Size = new System.Drawing.Size(185, 22);
            this.brightnessContrastToolStripMenuItem.Text = "Brightness - Contrast";
            this.brightnessContrastToolStripMenuItem.Click += new System.EventHandler(this.brightnessContrastToolStripMenuItem_Click);
            // 
            // inverseToolStripMenuItem
            // 
            this.inverseToolStripMenuItem.Name = "inverseToolStripMenuItem";
            this.inverseToolStripMenuItem.Size = new System.Drawing.Size(185, 22);
            this.inverseToolStripMenuItem.Text = "Inverse";
            this.inverseToolStripMenuItem.Click += new System.EventHandler(this.inverseToolStripMenuItem_Click);
            // 
            // logBrightnessToolStripMenuItem
            // 
            this.logBrightnessToolStripMenuItem.Name = "logBrightnessToolStripMenuItem";
            this.logBrightnessToolStripMenuItem.Size = new System.Drawing.Size(185, 22);
            this.logBrightnessToolStripMenuItem.Text = "Log Brightness";
            this.logBrightnessToolStripMenuItem.Click += new System.EventHandler(this.logBrightnessToolStripMenuItem_Click);
            // 
            // logContrastToolStripMenuItem
            // 
            this.logContrastToolStripMenuItem.Name = "logContrastToolStripMenuItem";
            this.logContrastToolStripMenuItem.Size = new System.Drawing.Size(185, 22);
            this.logContrastToolStripMenuItem.Text = "Log Contrast";
            this.logContrastToolStripMenuItem.Click += new System.EventHandler(this.logContrastToolStripMenuItem_Click);
            // 
            // gammaTransformToolStripMenuItem
            // 
            this.gammaTransformToolStripMenuItem.Name = "gammaTransformToolStripMenuItem";
            this.gammaTransformToolStripMenuItem.Size = new System.Drawing.Size(185, 22);
            this.gammaTransformToolStripMenuItem.Text = "Gamma Transform";
            this.gammaTransformToolStripMenuItem.Click += new System.EventHandler(this.gammaTransformToolStripMenuItem_Click);
            // 
            // bitDepthToolStripMenuItem
            // 
            this.bitDepthToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.satubitToolStripMenuItem,
            this.duabitToolStripMenuItem,
            this.tigabitToolStripMenuItem,
            this.empatbitToolStripMenuItem,
            this.limabitToolStripMenuItem,
            this.enambitToolStripMenuItem,
            this.tujuhbitToolStripMenuItem});
            this.bitDepthToolStripMenuItem.Name = "bitDepthToolStripMenuItem";
            this.bitDepthToolStripMenuItem.Size = new System.Drawing.Size(185, 22);
            this.bitDepthToolStripMenuItem.Text = "Bit Depth";
            // 
            // satubitToolStripMenuItem
            // 
            this.satubitToolStripMenuItem.Name = "satubitToolStripMenuItem";
            this.satubitToolStripMenuItem.Size = new System.Drawing.Size(94, 22);
            this.satubitToolStripMenuItem.Text = "1bit";
            this.satubitToolStripMenuItem.Click += new System.EventHandler(this.satubitToolStripMenuItem_Click);
            // 
            // duabitToolStripMenuItem
            // 
            this.duabitToolStripMenuItem.Name = "duabitToolStripMenuItem";
            this.duabitToolStripMenuItem.Size = new System.Drawing.Size(94, 22);
            this.duabitToolStripMenuItem.Text = "2bit";
            this.duabitToolStripMenuItem.Click += new System.EventHandler(this.duabitToolStripMenuItem_Click);
            // 
            // tigabitToolStripMenuItem
            // 
            this.tigabitToolStripMenuItem.Name = "tigabitToolStripMenuItem";
            this.tigabitToolStripMenuItem.Size = new System.Drawing.Size(94, 22);
            this.tigabitToolStripMenuItem.Text = "3bit";
            this.tigabitToolStripMenuItem.Click += new System.EventHandler(this.tigabitToolStripMenuItem_Click);
            // 
            // empatbitToolStripMenuItem
            // 
            this.empatbitToolStripMenuItem.Name = "empatbitToolStripMenuItem";
            this.empatbitToolStripMenuItem.Size = new System.Drawing.Size(94, 22);
            this.empatbitToolStripMenuItem.Text = "4bit";
            this.empatbitToolStripMenuItem.Click += new System.EventHandler(this.empatbitToolStripMenuItem_Click);
            // 
            // limabitToolStripMenuItem
            // 
            this.limabitToolStripMenuItem.Name = "limabitToolStripMenuItem";
            this.limabitToolStripMenuItem.Size = new System.Drawing.Size(94, 22);
            this.limabitToolStripMenuItem.Text = "5bit";
            this.limabitToolStripMenuItem.Click += new System.EventHandler(this.limabitToolStripMenuItem_Click);
            // 
            // enambitToolStripMenuItem
            // 
            this.enambitToolStripMenuItem.Name = "enambitToolStripMenuItem";
            this.enambitToolStripMenuItem.Size = new System.Drawing.Size(94, 22);
            this.enambitToolStripMenuItem.Text = "6bit";
            this.enambitToolStripMenuItem.Click += new System.EventHandler(this.enambitToolStripMenuItem_Click);
            // 
            // tujuhbitToolStripMenuItem
            // 
            this.tujuhbitToolStripMenuItem.Name = "tujuhbitToolStripMenuItem";
            this.tujuhbitToolStripMenuItem.Size = new System.Drawing.Size(94, 22);
            this.tujuhbitToolStripMenuItem.Text = "7bit";
            this.tujuhbitToolStripMenuItem.Click += new System.EventHandler(this.tujuhbitToolStripMenuItem_Click);
            // 
            // imageProcessingToolStripMenuItem
            // 
            this.imageProcessingToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.histogramEqualizationToolStripMenuItem,
            this.fuzzyHERGBToolStripMenuItem,
            this.fuzzyHEGrayscaleToolStripMenuItem});
            this.imageProcessingToolStripMenuItem.Name = "imageProcessingToolStripMenuItem";
            this.imageProcessingToolStripMenuItem.Size = new System.Drawing.Size(112, 20);
            this.imageProcessingToolStripMenuItem.Text = "Image Processing";
            // 
            // histogramEqualizationToolStripMenuItem
            // 
            this.histogramEqualizationToolStripMenuItem.Name = "histogramEqualizationToolStripMenuItem";
            this.histogramEqualizationToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.histogramEqualizationToolStripMenuItem.Text = "Histogram Equalization";
            this.histogramEqualizationToolStripMenuItem.Click += new System.EventHandler(this.histogramEqualizationToolStripMenuItem_Click);
            // 
            // fuzzyHERGBToolStripMenuItem
            // 
            this.fuzzyHERGBToolStripMenuItem.Name = "fuzzyHERGBToolStripMenuItem";
            this.fuzzyHERGBToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.fuzzyHERGBToolStripMenuItem.Text = "Fuzzy HE RGB";
            this.fuzzyHERGBToolStripMenuItem.Click += new System.EventHandler(this.fuzzyHERGBToolStripMenuItem_Click);
            // 
            // fuzzyHEGrayscaleToolStripMenuItem
            // 
            this.fuzzyHEGrayscaleToolStripMenuItem.Name = "fuzzyHEGrayscaleToolStripMenuItem";
            this.fuzzyHEGrayscaleToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.fuzzyHEGrayscaleToolStripMenuItem.Text = "Fuzzy HE Grayscale";
            this.fuzzyHEGrayscaleToolStripMenuItem.Click += new System.EventHandler(this.fuzzyHEGrayscaleToolStripMenuItem_Click);
            // 
            // viewToolStripMenuItem
            // 
            this.viewToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.rGBHistogramToolStripMenuItem,
            this.grayscaleHistogramToolStripMenuItem});
            this.viewToolStripMenuItem.Name = "viewToolStripMenuItem";
            this.viewToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.viewToolStripMenuItem.Text = "View";
            // 
            // rGBHistogramToolStripMenuItem
            // 
            this.rGBHistogramToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.inputToolStripMenuItem,
            this.outputToolStripMenuItem,
            this.inputOutputToolStripMenuItem});
            this.rGBHistogramToolStripMenuItem.Name = "rGBHistogramToolStripMenuItem";
            this.rGBHistogramToolStripMenuItem.Size = new System.Drawing.Size(183, 22);
            this.rGBHistogramToolStripMenuItem.Text = "RGB Histogram";
            this.rGBHistogramToolStripMenuItem.Click += new System.EventHandler(this.rGBHistogramToolStripMenuItem_Click);
            // 
            // inputToolStripMenuItem
            // 
            this.inputToolStripMenuItem.Name = "inputToolStripMenuItem";
            this.inputToolStripMenuItem.Size = new System.Drawing.Size(143, 22);
            this.inputToolStripMenuItem.Text = "Input";
            this.inputToolStripMenuItem.Click += new System.EventHandler(this.inputToolStripMenuItem_Click);
            // 
            // outputToolStripMenuItem
            // 
            this.outputToolStripMenuItem.Name = "outputToolStripMenuItem";
            this.outputToolStripMenuItem.Size = new System.Drawing.Size(143, 22);
            this.outputToolStripMenuItem.Text = "Output";
            this.outputToolStripMenuItem.Click += new System.EventHandler(this.outputToolStripMenuItem_Click);
            // 
            // inputOutputToolStripMenuItem
            // 
            this.inputOutputToolStripMenuItem.Name = "inputOutputToolStripMenuItem";
            this.inputOutputToolStripMenuItem.Size = new System.Drawing.Size(143, 22);
            this.inputOutputToolStripMenuItem.Text = "Input Output";
            this.inputOutputToolStripMenuItem.Click += new System.EventHandler(this.inputOutputToolStripMenuItem_Click);
            // 
            // grayscaleHistogramToolStripMenuItem
            // 
            this.grayscaleHistogramToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.inputToolStripMenuItem1,
            this.outputToolStripMenuItem1,
            this.inputOutputToolStripMenuItem1});
            this.grayscaleHistogramToolStripMenuItem.Name = "grayscaleHistogramToolStripMenuItem";
            this.grayscaleHistogramToolStripMenuItem.Size = new System.Drawing.Size(183, 22);
            this.grayscaleHistogramToolStripMenuItem.Text = "Grayscale Histogram";
            // 
            // inputToolStripMenuItem1
            // 
            this.inputToolStripMenuItem1.Name = "inputToolStripMenuItem1";
            this.inputToolStripMenuItem1.Size = new System.Drawing.Size(143, 22);
            this.inputToolStripMenuItem1.Text = "Input";
            this.inputToolStripMenuItem1.Click += new System.EventHandler(this.inputToolStripMenuItem1_Click);
            // 
            // outputToolStripMenuItem1
            // 
            this.outputToolStripMenuItem1.Name = "outputToolStripMenuItem1";
            this.outputToolStripMenuItem1.Size = new System.Drawing.Size(143, 22);
            this.outputToolStripMenuItem1.Text = "Output";
            this.outputToolStripMenuItem1.Click += new System.EventHandler(this.outputToolStripMenuItem1_Click);
            // 
            // inputOutputToolStripMenuItem1
            // 
            this.inputOutputToolStripMenuItem1.Name = "inputOutputToolStripMenuItem1";
            this.inputOutputToolStripMenuItem1.Size = new System.Drawing.Size(143, 22);
            this.inputOutputToolStripMenuItem1.Text = "Input Output";
            this.inputOutputToolStripMenuItem1.Click += new System.EventHandler(this.inputOutputToolStripMenuItem1_Click);
            // 
            // operasiAritmatikaToolStripMenuItem
            // 
            this.operasiAritmatikaToolStripMenuItem.Name = "operasiAritmatikaToolStripMenuItem";
            this.operasiAritmatikaToolStripMenuItem.Size = new System.Drawing.Size(117, 20);
            this.operasiAritmatikaToolStripMenuItem.Text = "Operasi Aritmatika";
            this.operasiAritmatikaToolStripMenuItem.Click += new System.EventHandler(this.operasiAritmatikaToolStripMenuItem_Click);
            // 
            // filterToolStripMenuItem
            // 
            this.filterToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hPFToolStripMenuItem,
            this.lowPassFilterToolStripMenuItem,
            this.highPassFilterToolStripMenuItem,
            this.bandPassFIlterToolStripMenuItem,
            this.lineDetectionToolStripMenuItem,
            this.pointDetectionToolStripMenuItem});
            this.filterToolStripMenuItem.Name = "filterToolStripMenuItem";
            this.filterToolStripMenuItem.Size = new System.Drawing.Size(45, 20);
            this.filterToolStripMenuItem.Text = "Filter";
            // 
            // hPFToolStripMenuItem
            // 
            this.hPFToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.prowitToolStripMenuItem,
            this.sobelToolStripMenuItem});
            this.hPFToolStripMenuItem.Name = "hPFToolStripMenuItem";
            this.hPFToolStripMenuItem.Size = new System.Drawing.Size(186, 22);
            this.hPFToolStripMenuItem.Text = "Edge Detection";
            // 
            // lowPassFilterToolStripMenuItem
            // 
            this.lowPassFilterToolStripMenuItem.Name = "lowPassFilterToolStripMenuItem";
            this.lowPassFilterToolStripMenuItem.Size = new System.Drawing.Size(186, 22);
            this.lowPassFilterToolStripMenuItem.Text = "Low Pass Filter";
            this.lowPassFilterToolStripMenuItem.Click += new System.EventHandler(this.lowPassFilterToolStripMenuItem_Click);
            // 
            // highPassFilterToolStripMenuItem
            // 
            this.highPassFilterToolStripMenuItem.Name = "highPassFilterToolStripMenuItem";
            this.highPassFilterToolStripMenuItem.Size = new System.Drawing.Size(186, 22);
            this.highPassFilterToolStripMenuItem.Text = "High Pass Filter";
            this.highPassFilterToolStripMenuItem.Click += new System.EventHandler(this.highPassFilterToolStripMenuItem_Click);
            // 
            // tentangToolStripMenuItem
            // 
            this.tentangToolStripMenuItem.Name = "tentangToolStripMenuItem";
            this.tentangToolStripMenuItem.Size = new System.Drawing.Size(62, 20);
            this.tentangToolStripMenuItem.Text = "Tentang";
            this.tentangToolStripMenuItem.Click += new System.EventHandler(this.tentangToolStripMenuItem_Click);
            // 
            // pbInput
            // 
            this.pbInput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbInput.Location = new System.Drawing.Point(9, 41);
            this.pbInput.Margin = new System.Windows.Forms.Padding(2);
            this.pbInput.Name = "pbInput";
            this.pbInput.Size = new System.Drawing.Size(376, 285);
            this.pbInput.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbInput.TabIndex = 1;
            this.pbInput.TabStop = false;
            // 
            // pbOutput
            // 
            this.pbOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbOutput.Location = new System.Drawing.Point(398, 41);
            this.pbOutput.Margin = new System.Windows.Forms.Padding(2);
            this.pbOutput.Name = "pbOutput";
            this.pbOutput.Size = new System.Drawing.Size(376, 285);
            this.pbOutput.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbOutput.TabIndex = 2;
            this.pbOutput.TabStop = false;
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.toolStripStatusLabel2});
            this.statusStrip1.Location = new System.Drawing.Point(0, 362);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Padding = new System.Windows.Forms.Padding(1, 0, 10, 0);
            this.statusStrip1.Size = new System.Drawing.Size(782, 22);
            this.statusStrip1.TabIndex = 3;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(61, 17);
            this.toolStripStatusLabel1.Text = "Lokasi File";
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(77, 17);
            this.toolStripStatusLabel2.Text = "| Resolusi File";
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(327, 364);
            this.progressBar1.Margin = new System.Windows.Forms.Padding(2);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(169, 20);
            this.progressBar1.TabIndex = 4;
            this.progressBar1.Visible = false;
            // 
            // bandPassFIlterToolStripMenuItem
            // 
            this.bandPassFIlterToolStripMenuItem.Name = "bandPassFIlterToolStripMenuItem";
            this.bandPassFIlterToolStripMenuItem.Size = new System.Drawing.Size(186, 22);
            this.bandPassFIlterToolStripMenuItem.Text = "Band Pass FIlter";
            this.bandPassFIlterToolStripMenuItem.Click += new System.EventHandler(this.bandPassFIlterToolStripMenuItem_Click);
            // 
            // prowitToolStripMenuItem
            // 
            this.prowitToolStripMenuItem.Name = "prowitToolStripMenuItem";
            this.prowitToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.prowitToolStripMenuItem.Text = "Prowit";
            this.prowitToolStripMenuItem.Click += new System.EventHandler(this.prowitToolStripMenuItem_Click);
            // 
            // sobelToolStripMenuItem
            // 
            this.sobelToolStripMenuItem.Name = "sobelToolStripMenuItem";
            this.sobelToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.sobelToolStripMenuItem.Text = "Sobel";
            this.sobelToolStripMenuItem.Click += new System.EventHandler(this.sobelToolStripMenuItem_Click);
            // 
            // lineDetectionToolStripMenuItem
            // 
            this.lineDetectionToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.horizontalToolStripMenuItem,
            this.verticalToolStripMenuItem,
            this.toolStripMenuItem2,
            this.toolStripMenuItem3});
            this.lineDetectionToolStripMenuItem.Name = "lineDetectionToolStripMenuItem";
            this.lineDetectionToolStripMenuItem.Size = new System.Drawing.Size(186, 22);
            this.lineDetectionToolStripMenuItem.Text = "Line Detection";
            // 
            // horizontalToolStripMenuItem
            // 
            this.horizontalToolStripMenuItem.Name = "horizontalToolStripMenuItem";
            this.horizontalToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.horizontalToolStripMenuItem.Text = "Horizontal";
            this.horizontalToolStripMenuItem.Click += new System.EventHandler(this.horizontalToolStripMenuItem_Click);
            // 
            // verticalToolStripMenuItem
            // 
            this.verticalToolStripMenuItem.Name = "verticalToolStripMenuItem";
            this.verticalToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.verticalToolStripMenuItem.Text = "Vertical";
            this.verticalToolStripMenuItem.Click += new System.EventHandler(this.verticalToolStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(180, 22);
            this.toolStripMenuItem2.Text = "+45";
            this.toolStripMenuItem2.Click += new System.EventHandler(this.toolStripMenuItem2_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(180, 22);
            this.toolStripMenuItem3.Text = "-45";
            this.toolStripMenuItem3.Click += new System.EventHandler(this.toolStripMenuItem3_Click);
            // 
            // pointDetectionToolStripMenuItem
            // 
            this.pointDetectionToolStripMenuItem.Name = "pointDetectionToolStripMenuItem";
            this.pointDetectionToolStripMenuItem.Size = new System.Drawing.Size(186, 22);
            this.pointDetectionToolStripMenuItem.Text = "Point Detection";
            this.pointDetectionToolStripMenuItem.Click += new System.EventHandler(this.pointDetectionToolStripMenuItem_Click);
            // 
            // FormMaster
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(782, 384);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.pbOutput);
            this.Controls.Add(this.pbInput);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "FormMaster";
            this.Text = "Image Editor";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbInput)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbOutput)).EndInit();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bukaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem simpanSebagaiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem keluarAplikasiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem colorsToolStripMenuItem;
        private System.Windows.Forms.PictureBox pbInput;
        private System.Windows.Forms.PictureBox pbOutput;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.ToolStripMenuItem tentangToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem grayscaleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem averageToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lightnessToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem luminanceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem brightnessContrastToolStripMenuItem;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.ToolStripMenuItem inverseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem logBrightnessToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem logContrastToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gammaTransformToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bitDepthToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem satubitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem duabitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tigabitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem empatbitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem limabitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem enambitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tujuhbitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rGBHistogramToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem inputToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem outputToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem inputOutputToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem grayscaleHistogramToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem inputToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem outputToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem inputOutputToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem imageProcessingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem histogramEqualizationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fuzzyHERGBToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fuzzyHEGrayscaleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem operasiAritmatikaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem filterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hPFToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lowPassFilterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem highPassFilterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bandPassFIlterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem prowitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sobelToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lineDetectionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem horizontalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem verticalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem pointDetectionToolStripMenuItem;
    }
}

